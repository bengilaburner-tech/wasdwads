import { createHash, randomBytes, scrypt as _scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";

const scrypt = promisify(_scrypt);
const PASSWORD_HASH_PREFIX = "scrypt";
const PASSWORD_SALT_BYTES = 16;
const PASSWORD_KEY_LENGTH = 64;
const PASSWORD_SCRYPT_OPTIONS = { N: 16384, r: 8, p: 1 };
const LEGACY_STATIC_SALT = "salt";

/**
 * Generate a simple ID
 */
export function generateId(): string {
	return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

/**
 * Hash password using scrypt with a per-user random salt.
 */
export async function hashPassword(password: string): Promise<string> {
	const salt = randomBytes(PASSWORD_SALT_BYTES).toString("hex");
	const derived = (await scrypt(password, salt, PASSWORD_KEY_LENGTH, PASSWORD_SCRYPT_OPTIONS)) as Buffer;
	return `${PASSWORD_HASH_PREFIX}$${salt}$${derived.toString("hex")}`;
}

/**
 * Verify password against both modern and legacy hashes.
 * Legacy SHA-256 hashes are transparently upgraded on successful login.
 */
export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
	if (storedHash.startsWith(`${PASSWORD_HASH_PREFIX}$`)) {
		const [prefix, salt, derivedHex] = storedHash.split("$");
		if (prefix !== PASSWORD_HASH_PREFIX || !salt || !derivedHex) {
			return false;
		}

		const computed = (await scrypt(password, salt, PASSWORD_KEY_LENGTH, PASSWORD_SCRYPT_OPTIONS)) as Buffer;
		const expected = Buffer.from(derivedHex, "hex");
		if (computed.length !== expected.length) {
			return false;
		}

		return timingSafeEqual(computed, expected);
	}

	return legacyVerifyPassword(password, storedHash);
}

export function isLegacyPasswordHash(hash: string): boolean {
	return /^[0-9a-f]{64}$/.test(hash);
}

export function isModernPasswordHash(hash: string): boolean {
	return hash.startsWith(`${PASSWORD_HASH_PREFIX}$`);
}

function legacyVerifyPassword(password: string, hashedPassword: string): boolean {
	const hash = createHash("sha256");
	hash.update(password + LEGACY_STATIC_SALT);
	return hash.digest("hex") === hashedPassword;
}

/**
 * Convert Date to protobuf Timestamp
 */
export function toProtoTimestamp(date: Date): { seconds: bigint; nanos: number } {
	const ms = date.getTime();
	return {
		seconds: BigInt(Math.floor(ms / 1000)),
		nanos: (ms % 1000) * 1000000,
	};
}

/**
 * Convert protobuf Timestamp to Date
 */
export function fromProtoTimestamp(timestamp: { seconds: bigint; nanos: number }): Date {
	return new Date(Number(timestamp.seconds) * 1000 + timestamp.nanos / 1000000);
}
