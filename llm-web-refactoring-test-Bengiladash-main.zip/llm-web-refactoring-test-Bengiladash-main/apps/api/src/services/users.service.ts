import { eq } from "drizzle-orm";
import { db, schema } from "../db";
import { loadUserProfileCounts } from "./query-utils";

const { users, follows, posts } = schema;

export interface UpdateProfileInput {
	userId: string;
	displayName?: string;
	bio?: string;
	avatarUrl?: string;
}

export async function getUser(username: string, requesterId?: string) {
	const user = await db
		.select({
			id: users.id,
			email: users.email,
			username: users.username,
			displayName: users.displayName,
			avatarUrl: users.avatarUrl,
			bio: users.bio,
			role: users.role,
			createdAt: users.createdAt,
		})
		.from(users)
		.where(eq(users.username, username))
		.get();

	if (!user) {
		throw new Error("User not found");
	}

	const counts = await loadUserProfileCounts(user.id, requesterId);

	return {
		...user,
		...counts,
	};
}

export async function updateProfile(input: UpdateProfileInput) {
	const updateData: Record<string, string> = {};

	if (input.displayName !== undefined) {
		updateData.displayName = input.displayName;
	}

	if (input.bio !== undefined) {
		updateData.bio = input.bio;
	}

	if (input.avatarUrl !== undefined) {
		updateData.avatarUrl = input.avatarUrl;
	}

	if (Object.keys(updateData).length === 0) {
		return { success: true };
	}

	await db
		.update(users)
		.set({
			...updateData,
			updatedAt: new Date(),
		})
		.where(eq(users.id, input.userId));

	return { success: true };
}
