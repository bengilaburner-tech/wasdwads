import { randomUUID } from "crypto";

export interface TraceContext {
	traceId: string;
	startTime: number;
	metadata: Record<string, unknown>;
}

const traceContextMap = new WeakMap<object, TraceContext>();

/**
 * Generate a unique trace ID for request tracking
 */
export function generateTraceId(): string {
	return randomUUID();
}

/**
 * Create a new trace context for a request
 */
export function createTraceContext(metadata: Record<string, unknown> = {}): TraceContext {
	return {
		traceId: generateTraceId(),
		startTime: Date.now(),
		metadata,
	};
}

/**
 * Store trace context for a given object/request
 */
export function setTraceContext(obj: object, context: TraceContext): void {
	traceContextMap.set(obj, context);
}

/**
 * Retrieve trace context for a given object/request
 */
export function getTraceContext(obj: object): TraceContext | undefined {
	return traceContextMap.get(obj);
}

/**
 * Structured logging interface
 */
export interface LogEntry {
	level: "debug" | "info" | "warn" | "error";
	message: string;
	traceId: string;
	timestamp: string;
	duration?: number;
	context?: Record<string, unknown>;
	error?: {
		code?: string;
		message?: string;
		stack?: string;
	};
}

/**
 * Structured logger with trace ID propagation
 */
export class Logger {
	private static toIsoString(timestamp: number): string {
		return new Date(timestamp).toISOString();
	}

	private static formatEntry(entry: LogEntry): string {
		return JSON.stringify(entry);
	}

	static debug(
		message: string,
		traceId: string,
		context?: Record<string, unknown>,
	): void {
		const entry: LogEntry = {
			level: "debug",
			message,
			traceId,
			timestamp: this.toIsoString(Date.now()),
			context,
		};
		if (process.env.LOG_LEVEL === "debug") {
			console.log(this.formatEntry(entry));
		}
	}

	static info(
		message: string,
		traceId: string,
		context?: Record<string, unknown>,
	): void {
		const entry: LogEntry = {
			level: "info",
			message,
			traceId,
			timestamp: this.toIsoString(Date.now()),
			context,
		};
		console.log(this.formatEntry(entry));
	}

	static warn(
		message: string,
		traceId: string,
		context?: Record<string, unknown>,
	): void {
		const entry: LogEntry = {
			level: "warn",
			message,
			traceId,
			timestamp: this.toIsoString(Date.now()),
			context,
		};
		console.warn(this.formatEntry(entry));
	}

	static error(
		message: string,
		traceId: string,
		error?: Error,
		context?: Record<string, unknown>,
	): void {
		const entry: LogEntry = {
			level: "error",
			message,
			traceId,
			timestamp: this.toIsoString(Date.now()),
			context,
			error: error
				? {
						code: (error as any).code,
						message: error.message,
						stack: error.stack,
					}
				: undefined,
		};
		console.error(this.formatEntry(entry));
	}

	static request(
		method: string,
		traceId: string,
		context: Record<string, unknown> = {},
	): void {
		this.info(`${method} request started`, traceId, {
			...context,
			endpoint: method,
		});
	}

	static response(
		method: string,
		traceId: string,
		startTime: number,
		success: boolean = true,
		context: Record<string, unknown> = {},
	): void {
		const duration = Date.now() - startTime;
		this.info(`${method} request completed`, traceId, {
			...context,
			endpoint: method,
			duration,
			success,
		});
	}
}
