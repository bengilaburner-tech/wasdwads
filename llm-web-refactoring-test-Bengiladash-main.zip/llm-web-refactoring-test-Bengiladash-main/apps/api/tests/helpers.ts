import { db, schema } from "../src/db";
import { generateId, hashPassword } from "../src/services/utils";

const { users, posts, comments, likes, follows, bookmarks, notifications, reports, auditLogs } = schema;

export interface TestUser {
	id: string;
	email: string;
	username: string;
	displayName: string;
	role: "user" | "admin" | "moderator";
}

/**
 * USER CREATION HELPERS
 */

export async function createTestUser(
	overrides: Partial<{
		email: string;
		username: string;
		displayName: string;
		password: string;
		role: "user" | "admin" | "moderator";
	}> = {},
): Promise<TestUser> {
	const id = generateId();
	const email = overrides.email || `test-${id}@example.com`;
	const username = overrides.username || `user-${id}`;
	const displayName = overrides.displayName || `Test User ${id}`;
	const password = overrides.password || "password123";
	const role = overrides.role || "user";

	const passwordHash = await hashPassword(password);

	await db.insert(users).values({
		id,
		email,
		username,
		displayName,
		passwordHash,
		role,
	});

	return { id, email, username, displayName, role };
}

/**
 * Create a banned user for testing moderation workflows
 */
export async function createBannedUser(
	reason = "Violating community guidelines",
	adminId?: string,
): Promise<TestUser> {
	const user = await createTestUser();
	const admin = adminId || (await createTestUser({ role: "admin" })).id;

	await db
		.update(users)
		.set({
			bannedAt: Date.now(),
			bannedReason: reason,
			bannedBy: admin,
		})
		.where(({ id }: any) => id.eq(user.id));

	return user;
}

/**
 * Create an admin user
 */
export async function createAdminUser(): Promise<TestUser> {
	return createTestUser({ role: "admin" });
}

/**
 * Create a moderator user
 */
export async function createModeratorUser(): Promise<TestUser> {
	return createTestUser({ role: "moderator" });
}

/**
 * POST CREATION HELPERS
 */

export async function createTestPost(
	authorId: string,
	content = "Test post content",
): Promise<string> {
	const id = generateId();
	await db.insert(posts).values({
		id,
		content,
		authorId,
	});
	return id;
}

/**
 * Create multiple posts for a user (bulk operation)
 */
export async function createPostsForUser(userId: string, count: number): Promise<string[]> {
	const postIds: string[] = [];
	for (let i = 0; i < count; i++) {
		const postId = await createTestPost(userId, `Post ${i + 1} content`);
		postIds.push(postId);
	}
	return postIds;
}

/**
 * COMMENT CREATION HELPERS
 */

export async function createTestComment(
	postId: string,
	authorId: string,
	content = "Test comment",
): Promise<string> {
	const id = generateId();
	await db.insert(comments).values({
		id,
		content,
		postId,
		authorId,
	});
	return id;
}

/**
 * Create a reply to a comment (nested comment)
 */
export async function createCommentReply(
	parentCommentId: string,
	postId: string,
	authorId: string,
	content = "Test reply",
): Promise<string> {
	const id = generateId();
	await db.insert(comments).values({
		id,
		content,
		postId,
		authorId,
		parentId: parentCommentId,
	});
	return id;
}

/**
 * Create a comment thread (parent + replies)
 */
export async function createCommentThread(
	postId: string,
	authorId: string,
	depth = 3,
): Promise<{ comments: string[]; parentCommentId: string }> {
	const comments_list: string[] = [];
	let parentId = await createTestComment(postId, authorId, "Root comment");
	comments_list.push(parentId);

	for (let i = 1; i < depth; i++) {
		const replyId = await createCommentReply(parentId, postId, authorId, `Reply ${i}`);
		comments_list.push(replyId);
		parentId = replyId;
	}

	return { comments: comments_list, parentCommentId: comments_list[0] };
}

/**
 * LIKE/ENGAGEMENT HELPERS
 */

export async function createTestLike(userId: string, postId: string): Promise<string> {
	const id = generateId();
	await db.insert(likes).values({
		id,
		userId,
		postId,
	});
	return id;
}

/**
 * Create likes on a post from multiple users
 */
export async function createLikesOnPost(postId: string, userCount: number): Promise<string[]> {
	const likeIds: string[] = [];
	for (let i = 0; i < userCount; i++) {
		const user = await createTestUser();
		const likeId = await createTestLike(user.id, postId);
		likeIds.push(likeId);
	}
	return likeIds;
}

/**
 * FOLLOW HELPERS
 */

export async function createTestFollow(followerId: string, followingId: string): Promise<string> {
	const id = generateId();
	await db.insert(follows).values({
		id,
		followerId,
		followingId,
	});
	return id;
}

/**
 * Create a follow relationship between multiple users
 */
export async function createFollowChain(userCount = 3): Promise<string[]> {
	const userIds: string[] = [];
	for (let i = 0; i < userCount; i++) {
		const user = await createTestUser();
		userIds.push(user.id);

		// Make each user follow the previous one
		if (i > 0) {
			await createTestFollow(user.id, userIds[i - 1]);
		}
	}
	return userIds;
}

/**
 * BOOKMARK HELPERS
 */

export async function createTestBookmark(userId: string, postId: string): Promise<string> {
	const id = generateId();
	await db.insert(bookmarks).values({
		id,
		userId,
		postId,
	});
	return id;
}

/**
 * NOTIFICATION HELPERS
 */

export async function createTestNotification(
	userId: string,
	type: string,
	actorId: string,
	postId?: string,
): Promise<string> {
	const id = generateId();
	await db.insert(notifications).values({
		id,
		userId,
		type,
		actorId,
		postId,
	});
	return id;
}

/**
 * REPORT HELPERS
 */

export async function createTestReport(
	reporterId: string,
	targetType: string,
	targetId: string,
	reason = "Spam",
): Promise<string> {
	const id = generateId();
	await db.insert(reports).values({
		id,
		reporterId,
		targetType,
		targetId,
		reason,
	});
	return id;
}

/**
 * AUDIT LOG HELPERS
 */

export async function createTestAuditLog(
	adminId: string,
	action: string,
	targetType?: string,
	targetId?: string,
): Promise<string> {
	const id = generateId();
	await db.insert(auditLogs).values({
		id,
		adminId,
		action,
		targetType,
		targetId,
	});
	return id;
}

/**
 * ERROR SCENARIO HELPERS
 */

/**
 * Verify a user cannot be found (useful for deleted user tests)
 */
export async function assertUserNotFound(userId: string): Promise<boolean> {
	const result = await db.select().from(users).where(({ id }: any) => id.eq(userId)).get();
	return result === undefined;
}

/**
 * Verify a post cannot be found (useful for deleted post tests)
 */
export async function assertPostNotFound(postId: string): Promise<boolean> {
	const result = await db.select().from(posts).where(({ id }: any) => id.eq(postId)).get();
	return result === undefined;
}

/**
 * Verify cascade delete worked (post deleted means comments also deleted)
 */
export async function assertCascadeDeleted(parentId: string, childTable: any, foreignKeyName: string): Promise<boolean> {
	const result = await db.select().from(childTable).where((row: any) => row[foreignKeyName].eq(parentId)).all();
	return result.length === 0;
}

/**
 * Get count of records in a table (useful for verification)
 */
export async function getTableCount(table: any): Promise<number> {
	const result = (await db.select().from(table).all()) as any[];
	return result.length;
}

/**
 * Verify constraints are working (try to violate a unique constraint)
 */
export async function attemptConstraintViolation(
	table: any,
	columns: Record<string, any>,
): Promise<boolean> {
	try {
		await db.insert(table).values(columns);
		await db.insert(table).values(columns);
		return false; // Should have thrown
	} catch {
		return true; // Expected constraint violation
	}
}
