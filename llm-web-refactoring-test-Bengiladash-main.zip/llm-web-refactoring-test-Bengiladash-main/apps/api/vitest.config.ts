import { defineConfig } from "vitest/config";

export default defineConfig({
	test: {
		globals: true,
		environment: "node",
		include: ["src/**/*.test.ts", "tests/**/*.test.ts"],
		setupFiles: ["./tests/setup.ts"],

		/**
		 * Test Isolation Configuration
		 *
		 * - isolate: true (default) - Each test file runs in isolation
		 * - threads: true (default) - Tests can run in parallel
		 * - singleThread: false (default) - Allow parallel execution when safe
		 *
		 * For database tests, we rely on:
		 * 1. In-memory database per test file (vitest isolates by default)
		 * 2. afterEach cleanup (not beforeEach) to ensure data removal before next test
		 * 3. Mock isolation via vi.clearAllMocks() in test suites
		 */
		isolate: true, // Each file runs in isolated environment
		threads: true, // Enable parallel test execution
		maxThreads: 4, // Limit parallel workers to prevent resource exhaustion
		minThreads: 1,

		coverage: {
			provider: "v8",
			reporter: ["text", "json", "html"],
			include: ["src/services/**/*.ts"],
			exclude: ["src/**/*.test.ts"],
		},
	},
});
